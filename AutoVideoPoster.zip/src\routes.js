import { Router } from 'express';
import * as db from './db.js';
import { getLogs, log } from './utils.js';
import { requireAuth, requireApiKey } from './auth.js';
import fs from 'fs';
import { join } from 'path';

const router = Router();

// ─── Helper: get user ID from request (supports both auth and API key) ──
function getUserId(req) {
  return req.user?.id || null;
}

function generateRandomString(length) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) result += chars.charAt(Math.floor(Math.random() * chars.length));
  return result;
}

// ─── GET /api/videos – list all videos ──────────────────────────
router.get('/api/videos', requireApiKey, (req, res) => {
  const userId = getUserId(req);
  const videos = userId ? db.getUserVideos(userId) : db.getAllVideos();
  res.json(videos);
});

// ─── GET /api/videos/:id – get single video ─────────────────────
router.get('/api/videos/:id', (req, res) => {
  const video = db.getVideo(Number(req.params.id));
  if (!video) return res.status(404).json({ error: 'Video not found' });
  res.json(video);
});

// ─── POST /api/videos – add a new video ─────────────────────────
router.post('/api/videos', requireApiKey, (req, res) => {
  const userId = getUserId(req);
  const { video_url, title, caption, scheduled_at, delete_after_minutes, account_id } = req.body;

  if (!video_url) return res.status(400).json({ error: 'video_url is required' });
  if (!scheduled_at) return res.status(400).json({ error: 'scheduled_at is required' });

  const schedDate = new Date(scheduled_at);
  if (isNaN(schedDate.getTime())) {
    return res.status(400).json({ error: 'Invalid scheduled_at datetime. Use ISO format (e.g. 2026-08-22T15:30:00)' });
  }

  let video;
  if (userId) {
    video = db.addUserVideo({
      user_id: userId,
      video_url,
      title: title || '',
      caption: caption || '',
      platform: 'youtube',
      account_id: account_id || null,
      scheduled_at: schedDate.toISOString(),
      delete_after_minutes: delete_after_minutes ?? 60,
    });
  } else {
    video = db.addVideo({
      video_url,
      title: title || '',
      caption: caption || '',
      platform: 'youtube',
      account_id: account_id || null,
      scheduled_at: schedDate.toISOString(),
      delete_after_minutes: delete_after_minutes ?? 60,
    });
  }

  res.status(201).json(video);
});

// ─── POST /api/videos/multi – add video to multiple accounts ────
router.post('/api/videos/multi', requireApiKey, (req, res) => {
  const userId = getUserId(req);
  const { video_url, title, caption, scheduled_at, delete_after_minutes, platform, account_ids } = req.body;

  if (!video_url) return res.status(400).json({ error: 'video_url is required' });
  if (!scheduled_at) return res.status(400).json({ error: 'scheduled_at is required' });
  if (!account_ids || !Array.isArray(account_ids) || account_ids.length === 0) {
    return res.status(400).json({ error: 'At least one account_id is required' });
  }

  const schedDate = new Date(scheduled_at);
  if (isNaN(schedDate.getTime())) {
    return res.status(400).json({ error: 'Invalid scheduled_at datetime' });
  }

  const videos = [];
  
  for (const accountId of account_ids) {
    let video;
    if (userId) {
      video = db.addUserVideo({
        user_id: userId,
        video_url,
        title: title || '',
        caption: caption || '',
        platform: 'youtube',
        account_id: accountId || null,
        scheduled_at: schedDate.toISOString(),
        delete_after_minutes: delete_after_minutes ?? 60,
      });
    } else {
      video = db.addVideo({
        video_url,
        title: title || '',
        caption: caption || '',
        platform: 'youtube',
        account_id: accountId || null,
        scheduled_at: schedDate.toISOString(),
        delete_after_minutes: delete_after_minutes ?? 60,
      });
    }
    videos.push(video);
  }

  log(`📹 Scheduled video for ${videos.length} account(s): ${title || video_url}`);
  res.status(201).json({ videos, count: videos.length });
});

// ─── DELETE /api/videos/:id – remove from queue ─────────────────
router.delete('/api/videos/:id', (req, res) => {
  const video = db.getVideo(Number(req.params.id));
  if (!video) return res.status(404).json({ error: 'Video not found' });

  db.removeVideo(video.id);
  res.json({ success: true, deleted_id: video.id });
});

// ─── PATCH /api/videos/:id/cancel – cancel a scheduled video ────
router.patch('/api/videos/:id/cancel', (req, res) => {
  const video = db.getVideo(Number(req.params.id));
  if (!video) return res.status(404).json({ error: 'Video not found' });

  if (video.status !== 'scheduled') {
    return res.status(400).json({ error: `Cannot cancel video with status '${video.status}'` });
  }

  db.updateStatus(video.id, 'deleted');
  res.json(db.getVideo(video.id));
});

// ─── PATCH /api/videos/:id/retry – re-queue a failed video ──────
router.patch('/api/videos/:id/retry', (req, res) => {
  const video = db.getVideo(Number(req.params.id));
  if (!video) return res.status(404).json({ error: 'Video not found' });

  if (video.status !== 'failed') {
    return res.status(400).json({ error: `Cannot retry video with status '${video.status}' — only failed videos can be retried` });
  }

  db.retryVideo(video.id);
  res.json(db.getVideo(video.id));
});

// ─── GET /api/stats – dashboard stats ───────────────────────────
router.get('/api/stats', requireApiKey, (req, res) => {
  const userId = getUserId(req);
  const stats = userId ? db.getUserStats(userId) : db.getStats();
  res.json(stats);
});

// ─── GET /api/settings – all settings ────────────────────────
router.get('/api/settings', (req, res) => {
  res.json(db.getSettings());
});

// ─── PUT /api/settings – bulk update settings ──────────────────
router.put('/api/settings', (req, res) => {
  const updates = req.body;
  if (!updates || typeof updates !== 'object') {
    return res.status(400).json({ error: 'Body must be a JSON object of key-value pairs' });
  }
  db.setSettings(updates);
  res.json(db.getSettings());
});

// ─── DELETE /api/settings/:key – remove a setting ──────────────
router.delete('/api/settings/:key', (req, res) => {
  db.deleteSetting(req.params.key);
  res.json({ success: true });
});

// ═══════════════════════════════════════════════════════════════════
// YouTube OAuth Flow (uses main server for callback)
// ═══════════════════════════════════════════════════════════════════

const YOUTUBE_SCOPES = ['https://www.googleapis.com/auth/youtube.upload', 'https://www.googleapis.com/auth/youtube.readonly'];
let ytPendingAuth = null;

router.post('/api/youtube/connect', (req, res) => {
  try {
    const secretPath = join(process.cwd(), 'client_secret.json');
    if (!fs.existsSync(secretPath)) {
      return res.json({ error: 'client_secret.json not found. Download it from Google Cloud Console and place it in the project root.' });
    }

    const secret = JSON.parse(fs.readFileSync(secretPath, 'utf8'));
    const client = secret.installed || secret.web;
    if (!client) return res.json({ error: 'Invalid client_secret.json format' });

    const state = generateRandomString(32);
    const port = process.env.PORT || 5500;
    const redirectUri = `http://localhost:${port}/api/youtube/callback`;
    
    const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?` +
      `client_id=${encodeURIComponent(client.client_id)}` +
      `&redirect_uri=${encodeURIComponent(redirectUri)}` +
      `&response_type=code` +
      `&scope=${encodeURIComponent(YOUTUBE_SCOPES.join(' '))}` +
      `&access_type=offline` +
      `&prompt=consent` +
      `&state=${state}`;

    ytPendingAuth = { client, state, redirectUri };

    res.json({ auth_url: authUrl });
  } catch (err) {
    res.json({ error: err.message });
  }
});

router.get('/api/youtube/callback', async (req, res) => {
  const code = req.query.code;
  const error = req.query.error;
  const returnedState = req.query.state;

  if (error) {
    return res.send(`<h1>❌ ${error}</h1><p>Close this tab and try again.</p>`);
  }

  if (!ytPendingAuth || returnedState !== ytPendingAuth.state) {
    return res.send('<h1>❌ Invalid state. Close this tab and try again.</h1>');
  }

  try {
    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: ytPendingAuth.client.client_id,
        client_secret: ytPendingAuth.client.client_secret,
        redirect_uri: ytPendingAuth.redirectUri,
        grant_type: 'authorization_code',
      }),
    });
    const tokens = await tokenRes.json();
    if (tokens.error) throw new Error(tokens.error_description || tokens.error);

    log(`🔍 Fetching YouTube channel info...`);
    const channelRes = await fetch(
      `https://www.googleapis.com/youtube/v3/channels?part=id,snippet&mine=true`,
      { headers: { Authorization: `Bearer ${tokens.access_token}` } }
    );
    const channelData = await channelRes.json();
    log(`🔍 YouTube channel response: ${JSON.stringify(channelData).substring(0, 500)}`);
    const channel = channelData.items?.[0];
    if (!channel) {
      const errMsg = channelData.error?.message || 'No channel found. Make sure you have a YouTube channel created (not just a Google account). Create one at youtube.com/channel_switcher';
      throw new Error(errMsg);
    }

    // Save to global settings
    db.setSettings({
      'yt.client_id': ytPendingAuth.client.client_id,
      'yt.client_secret': ytPendingAuth.client.client_secret,
      'yt.refresh_token': tokens.refresh_token || '',
      'yt.channel_id': channel.id,
      'yt.channel_name': channel.snippet.title,
    });

    // Auto-save to accounts table for future use
    const ytCredentials = JSON.stringify({
      client_id: ytPendingAuth.client.client_id,
      client_secret: ytPendingAuth.client.client_secret,
      refresh_token: tokens.refresh_token,
      channel_id: channel.id,
      channel_name: channel.snippet.title,
    });
    // Check if account already exists by channel_id
    const existingAccounts = db.getAccountsByPlatform('youtube');
    const existing = existingAccounts.find(a => {
      try { const c = JSON.parse(a.credentials); return c.channel_id === channel.id; } catch { return false; }
    });
    let isNew = true;
    if (existing) {
      db.updateAccount(existing.id, { credentials: ytCredentials });
      log(`🔄 Updated existing YouTube account: ${channel.snippet.title} (already connected)`);
      isNew = false;
    } else {
      db.addAccount({ name: channel.snippet.title, platform: 'youtube', credentials: ytCredentials });
      log(`✅ Connected new YouTube account: ${channel.snippet.title}`);
    }

    ytPendingAuth.result = {
      connected: true,
      is_new: isNew,
      client_id: ytPendingAuth.client.client_id,
      client_secret: ytPendingAuth.client.client_secret,
      refresh_token: tokens.refresh_token,
      channel_id: channel.id,
      channel_name: channel.snippet.title,
    };

    const msg = isNew 
      ? `✅ YouTube Connected: ${channel.snippet.title}` 
      : `🔄 YouTube Updated: ${channel.snippet.title} (already connected — credentials refreshed)`;
    res.send(`<h1>${msg}</h1><p>Close this tab and return to the poster.</p>`);
  } catch (err) {
    res.send(`<h1>❌ ${err.message}</h1><p>Close this tab and try again.</p>`);
  }
});

router.get('/api/youtube/status', (req, res) => {
  if (ytPendingAuth?.result) {
    res.json(ytPendingAuth.result);
  } else {
    res.json({ connected: false });
  }
});

// ─── GET /api/tunnel – tunnel info ──────────────────────────────
router.get('/api/tunnel', (req, res) => {
  const logFile = join(process.cwd(), 'tunnel-server.log');
  let tunnelUrl = null;
  try {
    if (fs.existsSync(logFile)) {
      const logContent = fs.readFileSync(logFile, 'utf8');
      const match = logContent.match(/https?:\/\/[a-z0-9-]+\.trycloudflare\.com/);
      if (match) tunnelUrl = match[0];
    }
  } catch {}
  
  if (!tunnelUrl && process.env.TUNNEL_URL) {
    tunnelUrl = process.env.TUNNEL_URL;
  }
  
  res.json({
    tunnel_active: !!tunnelUrl,
    tunnel_url: tunnelUrl,
    local_url: `http://localhost:${process.env.PORT || 5500}`,
    instructions: tunnelUrl 
      ? `Share this URL with any device anywhere in the world: ${tunnelUrl}`
      : 'Run start-tunnel.bat (Windows) or start-tunnel.sh (Linux/Mac) to enable global access',
  });
});

// ─── GET /api/logs – recent logs ────────────────────────────────
router.get('/api/logs', (req, res) => {
  const limit = Number(req.query.limit) || 50;
  res.json(getLogs(limit));
});

// ─── Migrate global settings to accounts ─────────────────────
router.post('/api/accounts/migrate', (req, res) => {
  let migrated = 0;

  // YouTube only
  const ytRefresh = db.getSetting('yt.refresh_token');
  const ytChannel = db.getSetting('yt.channel_id');
  if (ytRefresh && ytChannel) {
    const ytCreds = JSON.stringify({
      client_id: db.getSetting('yt.client_id') || '',
      client_secret: db.getSetting('yt.client_secret') || '',
      refresh_token: ytRefresh,
      channel_id: ytChannel,
      channel_name: db.getSetting('yt.channel_name') || 'YouTube Account',
    });
    const existing = db.getAccountsByPlatform('youtube').find(a => {
      try { return JSON.parse(a.credentials).channel_id === ytChannel; } catch { return false; }
    });
    if (!existing) {
      db.addAccount({ name: db.getSetting('yt.channel_name') || 'YouTube Account', platform: 'youtube', credentials: ytCreds });
      migrated++;
    }
  }

  res.json({ migrated, message: migrated > 0 ? `Migrated ${migrated} account(s) from global settings` : 'No new accounts to migrate' });
});

// ─── Save platform credentials as account ────────────────────
router.post('/api/accounts/save-platform', (req, res) => {
  const { platform, name, credentials } = req.body;
  if (!platform || !credentials) {
    return res.status(400).json({ error: 'platform and credentials are required' });
  }

  // Only YouTube is supported
  if (platform !== 'youtube') {
    return res.status(400).json({ error: 'Only YouTube platform is supported' });
  }

  let accountName = name;
  let credsObj = credentials;
  if (typeof credsObj === 'string') {
    try { credsObj = JSON.parse(credsObj); } catch { return res.status(400).json({ error: 'Invalid credentials JSON' }); }
  }

  if (!accountName) {
    accountName = credsObj.channel_name || `YouTube ${new Date().toLocaleDateString()}`;
  }

  const existingAccounts = db.getAccountsByPlatform('youtube');
  const existing = existingAccounts.find(a => {
    try { const c = JSON.parse(a.credentials); return c.channel_id === credsObj.channel_id; } catch { return false; }
  });

  if (existing) {
    db.updateAccount(existing.id, { name: accountName, credentials: JSON.stringify(credsObj) });
    log(`🔄 Updated existing YouTube account: ${accountName}`);
    res.json(db.getAccount(existing.id));
  } else {
    const account = db.addAccount({ name: accountName, platform: 'youtube', credentials: JSON.stringify(credsObj) });
    log(`✅ Saved new YouTube account: ${accountName}`);
    res.status(201).json(account);
  }
});

// ─── Accounts ─────────────────────────────────────────────────

router.get('/api/accounts', (req, res) => {
  const platform = req.query.platform;
  const accounts = platform ? db.getAccountsByPlatform(platform) : db.getAllAccounts();
  res.json(accounts);
});

router.get('/api/accounts/stats', (req, res) => {
  res.json(db.getAccountStats());
});

router.get('/api/accounts/:id', (req, res) => {
  const account = db.getAccount(Number(req.params.id));
  if (!account) return res.status(404).json({ error: 'Account not found' });
  res.json(account);
});

router.post('/api/accounts', (req, res) => {
  const { name, platform, credentials } = req.body;
  if (!name) return res.status(400).json({ error: 'name is required' });
  if (platform && platform !== 'youtube') {
    return res.status(400).json({ error: 'Only YouTube platform is supported' });
  }

  // Check for duplicate by channel_id
  let credsObj = credentials;
  if (typeof credsObj === 'string') {
    try { credsObj = JSON.parse(credsObj); } catch { credsObj = {}; }
  }

  if (credsObj?.channel_id) {
    const existingAccounts = db.getAccountsByPlatform('youtube');
    const existing = existingAccounts.find(a => {
      try { const c = JSON.parse(a.credentials); return c.channel_id === credsObj.channel_id; } catch { return false; }
    });

    if (existing) {
      // Update existing account instead of creating duplicate
      db.updateAccount(existing.id, { name, credentials: JSON.stringify(credsObj) });
      log(`🔄 Updated existing YouTube account: ${name} (already connected)`);
      return res.json({ ...db.getAccount(existing.id), updated: true, message: 'Account already connected — updated credentials' });
    }
  }

  const account = db.addAccount({
    name,
    platform: 'youtube',
    credentials: credentials ? JSON.stringify(credentials) : '{}',
  });
  log(`✅ Added new YouTube account: ${name}`);
  res.status(201).json(account);
});

router.put('/api/accounts/:id', (req, res) => {
  const account = db.getAccount(Number(req.params.id));
  if (!account) return res.status(404).json({ error: 'Account not found' });
  const { name, credentials, is_active } = req.body;
  const updated = db.updateAccount(account.id, {
    name,
    platform: 'youtube',
    credentials: credentials ? JSON.stringify(credentials) : undefined,
    is_active,
  });
  res.json(updated);
});

router.delete('/api/accounts/:id', (req, res) => {
  const account = db.getAccount(Number(req.params.id));
  if (!account) return res.status(404).json({ error: 'Account not found' });
  db.deleteAccount(account.id);
  res.json({ success: true, deleted_id: account.id });
});

// ─── Analytics endpoints ─────────────────────────────────────────

// ─── GET /api/quota – per-account YouTube daily quota tracker ────
router.get('/api/quota', (req, res) => {
  res.json(db.getQuotaStatus());
});


router.get('/api/analytics/overview', (req, res) => {
  res.json(db.getAnalyticsOverview());
});

router.get('/api/analytics/weekly', (req, res) => {
  res.json(db.getWeeklyHistory());
});

router.get('/api/analytics/monthly', (req, res) => {
  res.json(db.getMonthlyHistory());
});

router.get('/api/analytics/rates', (req, res) => {
  res.json(db.getSuccessRates());
});

router.get('/api/analytics/times', (req, res) => {
  res.json(db.getOptimalTimes());
});

router.get('/api/analytics/days', (req, res) => {
  res.json(db.getDayOfWeekStats());
});

router.get('/api/analytics/activity', (req, res) => {
  res.json(db.getRecentActivity());
});

export default router;
