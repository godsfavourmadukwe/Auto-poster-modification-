@echo off
title Auto Video Poster - Cloudflare Tunnel
color 0B

echo.
echo  ╔══════════════════════════════════════════════════════════╗
echo  ║     AUTO VIDEO POSTER - GLOBAL ACCESS (TUNNEL)         ║
echo  ╚══════════════════════════════════════════════════════════╝
echo.

:: Check if cloudflared is installed
echo [1/3] Checking Cloudflare Tunnel (cloudflared)...
where cloudflared >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  ❌ cloudflared is not installed!
    echo.
    echo  Install it from: https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/
    echo.
    echo  Quick install (run in admin terminal):
    echo    winget install cloudflare.cloudflared
    echo.
    echo  Or download from: https://github.com/cloudflare/cloudflared/releases
    echo.
    pause
    exit /b 1
)
echo  ✅ cloudflared found!

:: Check if Node.js is installed
echo [2/3] Checking Node.js...
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  ❌ Node.js is not installed!
    echo  Download from: https://nodejs.org
    pause
    exit /b 1
)
for /f "tokens=*" %%i in ('node --version') do set NODE_VER=%%i
echo  ✅ Node.js found: %NODE_VER%

:: Install dependencies if needed
if not exist "node_modules" (
    echo  Installing dependencies...
    call npm install --production
)

:: Start the server
echo [3/3] Starting server and tunnel...
echo.
echo  ╔══════════════════════════════════════════════════════════╗
echo  ║  Starting server on port 5500...                       ║
echo  ║  Creating Cloudflare Tunnel for global access...       ║
echo  ║                                                        ║
echo  ║  ⚠️  SAVE THE URL THAT APPEARS BELOW!                 ║
echo  ║  Share it with any device anywhere in the world.       ║
echo  ╚══════════════════════════════════════════════════════════╝
echo.

:: Start server in background
set PORT=5500
start /b node src/index.js > tunnel-server.log 2>&1

:: Wait for server to start
timeout /t 3 /nobreak >nul

:: Start Cloudflare Tunnel and capture output
echo Starting Cloudflare Tunnel...
echo.
cloudflared tunnel --url http://localhost:5500 2>&1 | findstr /i "trycloudflare"
echo.
echo ══════════════════════════════════════════════════════════════
echo  The URL above can be accessed from ANY device ANYWHERE!
echo  Share it with your other devices.
echo  Press Ctrl+C to stop.
echo ══════════════════════════════════════════════════════════════
pause
