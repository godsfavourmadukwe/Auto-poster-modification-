#!/bin/bash

# Auto Video Poster - Global Access via Cloudflare Tunnel
# Run: chmod +x start-tunnel.sh && ./start-tunnel.sh

set -e

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║     AUTO VIDEO POSTER - GLOBAL ACCESS (TUNNEL)         ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""

# Check if cloudflared is installed
echo "[1/3] Checking Cloudflare Tunnel (cloudflared)..."
if ! command -v cloudflared &> /dev/null; then
    echo ""
    echo -e "${RED}  ❌ cloudflared is not installed!${NC}"
    echo ""
    echo "  Install it:"
    echo "    macOS:   brew install cloudflared"
    echo "    Linux:   curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o cloudflared && chmod +x cloudflared && sudo mv cloudflared /usr/local/bin/"
    echo ""
    echo "  Or download from: https://github.com/cloudflare/cloudflared/releases"
    exit 1
fi
echo -e "  ✅ cloudflared found!"

# Check if Node.js is installed
echo "[2/3] Checking Node.js..."
if ! command -v node &> /dev/null; then
    echo -e "${RED}  ❌ Node.js is not installed!${NC}"
    echo "  Download from: https://nodejs.org"
    exit 1
fi
NODE_VER=$(node --version)
echo -e "  ✅ Node.js found: ${NODE_VER}"

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
    echo "  Installing dependencies..."
    npm install --production
fi

# Start the server
echo "[3/3] Starting server and tunnel..."
echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║  Starting server on port 5500...                       ║${NC}"
echo -e "${CYAN}║  Creating Cloudflare Tunnel for global access...       ║${NC}"
echo -e "${CYAN}║                                                        ║${NC}"
echo -e "${YELLOW}║  ⚠️  SAVE THE URL THAT APPEARS BELOW!                 ║${NC}"
echo -e "${CYAN}║  Share it with any device anywhere in the world.       ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""

# Start server in background
export PORT=5500
node src/index.js > tunnel-server.log 2>&1 &
SERVER_PID=$!

# Wait for server to start
sleep 3

# Start Cloudflare Tunnel
echo "Starting Cloudflare Tunnel..."
echo ""
echo -e "${GREEN}═════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  Copy the URL below and share it with any device!${NC}"
echo -e "${GREEN}  It works from ANYWHERE in the world.${NC}"
echo -e "${GREEN}═════════════════════════════════════════════════════════════${NC}"
echo ""

# Run cloudflared and filter for the URL
cloudflared tunnel --url http://localhost:5500 2>&1 | while IFS= read -r line; do
    echo "$line"
    # Extract and highlight the URL
    if echo "$line" | grep -q "trycloudflare.com"; then
        URL=$(echo "$line" | grep -oP 'https://[a-z0-9-]+\.trycloudflare\.com')
        if [ -n "$URL" ]; then
            echo ""
            echo -e "${GREEN}═════════════════════════════════════════════════════════════${NC}"
            echo -e "${GREEN}  🌍 YOUR GLOBAL URL: $URL${NC}"
            echo -e "${GREEN}  Share this with any device anywhere!${NC}"
            echo -e "${GREEN}═════════════════════════════════════════════════════════════${NC}"
        fi
    fi
done

# Cleanup on exit
kill $SERVER_PID 2>/dev/null
echo ""
echo "Server stopped."
