const logs = [];
const MAX_LOGS = 200;

export function log(msg) {
  const entry = {
    time: new Date().toISOString(),
    message: msg,
  };
  logs.unshift(entry);
  if (logs.length > MAX_LOGS) logs.length = MAX_LOGS;
  console.log(`[${entry.time}] ${msg}`);
}

export function getLogs(limit = 50) {
  return logs.slice(0, limit);
}
