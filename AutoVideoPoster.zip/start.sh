#!/bin/bash

# Auto Video Poster - Linux/Mac Starter
# Double-click or run: chmod +x start.sh && ./start.sh

set -e

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║           AUTO VIDEO POSTER - STARTER                  ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""

# Check if Node.js is installed
echo "[1/4] Checking Node.js installation..."
if ! command -v node &> /dev/null; then
    echo ""
    echo -e "${RED}  ❌ Node.js is not installed!${NC}"
    echo ""
    echo "  Please install Node.js from: https://nodejs.org"
    echo "  Download the LTS version."
    echo ""
    echo "  On macOS (with Homebrew): brew install node"
    echo "  On Ubuntu/Debian: sudo apt install nodejs npm"
    echo "  On Fedora: sudo dnf install nodejs"
    echo ""
    echo "  After installing, run this script again."
    exit 1
fi
NODE_VER=$(node --version)
echo -e "  ✅ Node.js found: ${NODE_VER}"

# Check if npm is installed
echo "[2/4] Checking npm installation..."
if ! command -v npm &> /dev/null; then
    echo ""
    echo -e "${RED}  ❌ npm is not installed!${NC}"
    echo "  Please reinstall Node.js from: https://nodejs.org"
    exit 1
fi
NPM_VER=$(npm --version)
echo -e "  ✅ npm found: v${NPM_VER}"

# Install dependencies
echo "[3/4] Installing dependencies (this may take a minute)..."
if [ ! -d "node_modules" ]; then
    npm install --production
    if [ $? -ne 0 ]; then
        echo ""
        echo -e "${RED}  ❌ Failed to install dependencies!${NC}"
        echo "  Please check your internet connection and try again."
        exit 1
    fi
    echo -e "  ✅ Dependencies installed successfully!"
else
    echo -e "  ✅ Dependencies already installed!"
fi

# Start the server
echo "[4/4] Starting Auto Video Poster server..."
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║  Server starting on http://localhost:5500               ║${NC}"
echo -e "${GREEN}║  Press Ctrl+C to stop the server                       ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""

# Open browser after 2 second delay (cross-platform)
(sleep 2 && (
    if command -v xdg-open &> /dev/null; then
        xdg-open http://localhost:5500 2>/dev/null
    elif command -v open &> /dev/null; then
        open http://localhost:5500 2>/dev/null
    fi
)) &

# Start the server
export PORT=5500
exec node src/index.js
