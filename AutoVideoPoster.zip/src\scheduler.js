import { log } from './utils.js';
import * as db from './db.js';

const YOUTUBE_API = 'https://www.googleapis.com/youtube/v3';
const POST_RETRY_MAX = 6;
const POST_RETRY_BASE_DELAY = 5000;

// ─── YouTube credential getter ───────────────────────────────

function getYouTubeCredentials(accountId) {
  // If specific account provided, use it
  if (accountId) {
    const account = db.getAccount(accountId);
    if (account) {
      try {
        const creds = JSON.parse(account.credentials);
        db.markAccountUsed(accountId);
        return { ...creds, account_name: account.name };
      } catch (e) {
        log(`⚠️  Invalid credentials for account ${account.name}`);
      }
    }
  }

  // Fallback to global settings
  return {
    api_key: db.getSetting('yt.api_key'),
    client_id: db.getSetting('yt.client_id'),
    client_secret: db.getSetting('yt.client_secret'),
    refresh_token: db.getSetting('yt.refresh_token'),
    channel_id: db.getSetting('yt.channel_id'),
  };
}

// ─── YouTube Data API v3 ──────────────────────────────────────

async function postToYouTube(video, creds) {
  if (!creds.api_key && !creds.refresh_token) {
    throw new Error('YouTube credentials not configured');
  }

  const caption = buildCaption(video);
  const title = (video.title || 'Untitled Video').substring(0, 100);

  // YouTube uses resumable upload
  const metadata = {
    snippet: {
      title,
      description: caption,
      tags: extractHashtags(caption),
      categoryId: '22', // People & Blogs
    },
    status: {
      privacyStatus: 'public',
      selfDeclaredMadeForKids: false,
    },
  };

  log(`📦 Uploading to YouTube: ${title}`);

  // Step 1: Get OAuth2 access token from refresh token
  let accessToken = creds.api_key; // API key fallback for public videos
  if (creds.refresh_token) {
    const tokenRes = await fetchWithRetry('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: creds.client_id,
        client_secret: creds.client_secret,
        refresh_token: creds.refresh_token,
        grant_type: 'refresh_token',
      }),
    });
    if (tokenRes.ok) {
      const tokenData = await tokenRes.json();
      accessToken = tokenData.access_token;
    }
  }

  // Step 2: Initiate resumable upload
  const initRes = await fetchWithRetry(
    `https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status`,
    {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'X-Upload-Content-Type': 'video/*',
      },
      body: JSON.stringify(metadata),
    }
  );

  if (!initRes.ok) {
    const err = await initRes.json().catch(() => ({}));
    throw new Error(`YouTube init failed: ${err?.error?.message || initRes.status}`);
  }

  const uploadUrl = initRes.headers.get('location');
  if (!uploadUrl) throw new Error('No upload URL returned from YouTube');

  // Step 3: Download video and upload to YouTube (use resolved URL if available)
  const downloadUrl = video._resolvedUrl || video.video_url;
  log(`📥 Downloading video from: ${downloadUrl.substring(0, 100)}...`);
  
  // Pre-check URL accessibility (non-fatal: transient HEAD failures shouldn't abort
  // the post — the actual download below is what matters)
  const urlCheck = await checkUrlAccessibility(downloadUrl);
  if (!urlCheck.accessible) {
    log(`⚠️  Pre-check failed (${urlCheck.error || 'server error'}) — attempting download anyway`);
  }
  
  // Download with browser-like headers to bypass CDN anti-bot measures
  const videoRes = await fetchWithRetry(downloadUrl, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Accept': 'video/mp4,video/*;q=0.9,*/*;q=0.8',
      'Accept-Language': 'en-US,en;q=0.9',
      'Referer': 'https://www.tikwm.com/',
    },
    redirect: 'follow',
  });
  
  // Log response details for debugging
  const contentType = videoRes.headers.get('content-type') || 'unknown';
  const contentLength = videoRes.headers.get('content-length') || 'unknown';
  log(`📡 Response: ${videoRes.status} | Content-Type: ${contentType} | Content-Length: ${contentLength}`);
  
  if (!videoRes.ok) throw new Error(`Failed to download video from ${downloadUrl.substring(0, 80)} — HTTP ${videoRes.status}`);

  const videoBuffer = Buffer.from(await videoRes.arrayBuffer());
  
  // Log first few bytes for debugging (file signature)
  const header = videoBuffer.slice(0, 12).toString('hex');
  log(`🔍 File header: ${header}`);
  
  // Validate minimum file size
  if (videoBuffer.length < 10000) {
    // Try to show what was actually downloaded
    const preview = videoBuffer.toString('utf8', 0, Math.min(500, videoBuffer.length));
    log(`❌ Downloaded content preview: ${preview.substring(0, 200)}`);
    throw new Error(`Downloaded file too small (${videoBuffer.length} bytes) — not a valid video. URL may have returned an error page. Content-Type: ${contentType}`);
  }
  
  // Check if content-type is actually a video
  if (!contentType.includes('video') && !contentType.includes('octet-stream')) {
    log(`⚠️  Warning: Content-Type is not video (${contentType}), but file size looks OK. Continuing upload.`);
  }
  
  // Check file signature (MP4 starts with ftyp box)
  const isMp4 = header.includes('66747970'); // ftyp in hex
  const isWebm = header.includes('1a45dfa3'); // WebM signature
  const isRiff = header.includes('52494646'); // RIFF (AVI)
  if (!isMp4 && !isWebm && !isRiff) {
    log(`⚠️  Warning: File header doesn't match known video formats (${header}). File may be corrupt or not a video.`);
  }
  
  // Log file size for debugging
  const sizeMB = (videoBuffer.length / 1024 / 1024).toFixed(1);
  log(`📊 Video size: ${sizeMB} MB`);

  const uploadRes = await fetchWithRetry(uploadUrl, {
    method: 'PUT',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'video/*',
      'Content-Length': videoBuffer.length,
    },
    body: videoBuffer,
  });

  if (!uploadRes.ok) {
    const err = await uploadRes.json().catch(() => ({}));
    throw new Error(`YouTube upload failed: ${err?.error?.message || uploadRes.status}`);
  }

  const uploadData = await uploadRes.json();
  const videoId = uploadData.id;

  log(`🚀 YouTube Published! Video ID: ${videoId}`);
  return { post_id: videoId, platform: 'youtube' };
}

async function deleteFromYouTube(videoId, creds) {
  if (!videoId) return { deleted: false };

  let accessToken = creds.api_key;
  if (creds.refresh_token) {
    const tokenRes = await fetchWithRetry('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: creds.client_id,
        client_secret: creds.client_secret,
        refresh_token: creds.refresh_token,
        grant_type: 'refresh_token',
      }),
    });
    if (tokenRes.ok) {
      const tokenData = await tokenRes.json();
      accessToken = tokenData.access_token;
    }
  }

  log(`🗑️  Deleting YouTube video: ${videoId}`);
  const res = await fetchWithRetry(
    `${YOUTUBE_API}/videos?id=${videoId}`,
    {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${accessToken}` },
    }
  );

  log(`🗑️  YouTube Deleted: ${videoId}`);
  return { deleted: true, video_id: videoId };
}

// ─── URL Resolver — extracts direct video URLs ────────────────

async function resolveVideoUrl(url) {
  // Already a direct video file
  if (/\.mp4|\.mov|\.avi|\.mkv|\.webm/i.test(url)) {
    return url;
  }

  // Google Drive
  const gdriveMatch = url.match(/drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (gdriveMatch) {
    return `https://drive.google.com/uc?export=download&id=${gdriveMatch[1]}`;
  }
  const gdriveMatch2 = url.match(/drive\.google\.com\/open\?id=([a-zA-Z0-9_-]+)/);
  if (gdriveMatch2) {
    return `https://drive.google.com/uc?export=download&id=${gdriveMatch2[1]}`;
  }

  // Dropbox — convert to direct link
  if (url.includes('dropbox.com')) {
    return url.replace('www.dropbox.com', 'dl.dropboxusercontent.com').replace('?dl=0', '?dl=1');
  }

  // Reddit — extract video
  const redditMatch = url.match(/reddit\.com\/r\/\w+\/comments\/(\w+)/);
  if (redditMatch) {
    try {
      const jsonUrl = `https://www.reddit.com/comments/${redditMatch[1]}.json`;
      const res = await fetchWithRetry(jsonUrl, { headers: { 'User-Agent': 'AutoVideoPoster/1.0' } });
      if (res.ok) {
        const data = await res.json();
        const media = data[0]?.data?.children[0]?.data?.media;
        if (media?.reddit_video?.fallback_url) {
          return media.reddit_video.fallback_url;
        }
      }
    } catch (e) { /* fall through */ }
  }

  // Twitter/X — extract video from tweet
  const twitterMatch = url.match(/(?:twitter|x)\.com\/\w+\/status\/(\d+)/);
  if (twitterMatch) {
    try {
      log(`🐦 Twitter/X link detected. Attempting to resolve...`);
      // Twitter videos require authentication — return original URL for now
    } catch (e) { /* fall through */ }
  }

  // If no resolution found, return original URL
  return url;
}

// ─── Helper functions ─────────────────────────────────────────

function buildCaption(video) {
  let caption = video.caption || '';

  if (!caption) {
    const template = db.getSetting('ig.default_caption') || '';
    caption = template.replace(/\{title\}/g, video.title || '');
  }

  const suffix = db.getSetting('ig.caption_suffix') || '';
  if (suffix) {
    caption = caption + '\n\n' + suffix;
  }

  return caption.trim();
}

function extractHashtags(text) {
  const matches = text.match(/#\w+/g);
  return matches ? matches.map(tag => tag.slice(1)) : [];
}

async function fetchWithRetry(url, options = {}, retries = POST_RETRY_MAX) {
  for (let i = 0; i <= retries; i++) {
    try {
      const fetchOptions = { ...options };
      if (i > 0) {
        // Force a fresh TCP connection on retries — long-running processes can
        // hold stale keep-alive sockets in undici's pool, causing 'fetch failed'
        fetchOptions.headers = { ...fetchOptions.headers, connection: 'close' };
      }
      const res = await fetch(url, fetchOptions);
      if (res.ok || i === retries) return res;
      
      // Rate limit — wait and retry
      if (res.status === 429) {
        const retryAfter = res.headers.get('Retry-After');
        const waitMs = retryAfter ? parseInt(retryAfter) * 1000 : POST_RETRY_BASE_DELAY * Math.pow(2, i);
        log(`⏳ Rate limited, waiting ${waitMs}ms...`);
        await sleep(waitMs);
        continue;
      }
      
      return res;
    } catch (err) {
      const cause = err.cause ? (err.cause.code || err.cause.message) : 'unknown';
      log(`⏳ Fetch error [${cause}] on ${String(url).substring(0, 60)}`);
      if (i === retries) throw err;
      const waitMs = POST_RETRY_BASE_DELAY * Math.pow(2, i);
      log(`⏳ Request failed, retrying in ${waitMs}ms... (${i + 1}/${retries})`);
      await sleep(waitMs);
    }
  }
}

// ─── Pre-check URL accessibility ─────────────────────────────
async function checkUrlAccessibility(url) {
  try {
    log(`🔍 Checking URL accessibility: ${url.substring(0, 80)}...`);
    const res = await fetch(url, {
      method: 'HEAD',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      },
      redirect: 'follow',
    });
    const contentType = res.headers.get('content-type') || 'unknown';
    const contentLength = res.headers.get('content-length') || 'unknown';
    log(`📡 HEAD response: ${res.status} | Content-Type: ${contentType} | Content-Length: ${contentLength}`);
    
    // Check if it looks like a video
    const isVideo = contentType.includes('video') || 
                    contentType.includes('octet-stream') || 
                    url.includes('.mp4') || 
                    url.includes('.mov') || 
                    url.includes('.webm');
    
    if (!isVideo) {
      log(`⚠️  URL does not appear to be a video file (Content-Type: ${contentType})`);
    }
    
    return { accessible: res.ok, contentType, contentLength, isVideo };
  } catch (err) {
    log(`❌ URL check failed: ${err.message}`);
    return { accessible: false, error: err.message };
  }
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

// ─── Main posting function ────────────────────────────────────

async function postVideo(video) {
  const platform = video.platform || 'youtube';
  
  // Check for test mode
  const testMode = db.getSetting('ig.test_mode') || db.getSetting('test_mode');
  if (testMode === 'true') {
    log(`🧪 TEST MODE: Simulated post to ${platform}`);
    return { post_id: `test_${Date.now()}`, platform };
  }

  // Resolve the video URL (handles social media links → direct file URLs)
  video._resolvedUrl = await resolveVideoUrl(video.video_url);
  if (video._resolvedUrl !== video.video_url) {
    log(`🔗 URL resolved: ${video._resolvedUrl.substring(0, 80)}...`);
  }

  const creds = getYouTubeCredentials(video.account_id);
  return postToYouTube(video, creds);
}

async function deletePost(video) {
  const platform = video.platform || 'youtube';
  
  // Check for test mode
  const testMode = db.getSetting('ig.test_mode') || db.getSetting('test_mode');
  if (testMode === 'true') {
    log(`🧪 TEST MODE: Simulated deletion of ${platform} post ${video.posted_media_id}`);
    return { deleted: true };
  }

  const creds = getYouTubeCredentials(video.account_id);
  const mediaId = video.posted_media_id;

  return deleteFromYouTube(mediaId, creds);
}

// ─── Scheduler ────────────────────────────────────────────────

let intervalId = null;

export function startScheduler() {
  if (intervalId) return;

  // ─── Crash recovery: un-stick videos frozen in transient states ───
  // If the process died mid-upload/mid-delete, those rows stay 'posting'/'deleting'
  // forever. Requeue them based on whether an upload actually completed.
  try {
    const stuck = db.getStuckVideos();
    for (const v of stuck) {
      if (v.status === 'deleting') {
        // Delete attempt was interrupted — restore to 'posted' keeping the original
        // posted_at so the overdue auto-delete re-fires on the next tick.
        db.restorePosted(v.id);
        log(`🔧 Recovery: video #${v.id} delete attempt interrupted — restored to 'posted'`);
      } else if (v.posted_media_id) {
        // Upload actually completed before the crash — treat as posted so the
        // auto-delete timer can still fire.
        db.markPosted(v.id);
        log(`🔧 Recovery: video #${v.id} was mid-upload with a completed upload — marked as posted`);
      } else {
        db.retryVideo(v.id);
        log(`🔧 Recovery: video #${v.id} was stuck in 'posting' — re-queued`);
      }
    }
    if (stuck.length) log(`🔧 Crash recovery processed ${stuck.length} stuck video(s)`);
  } catch (err) {
    log(`⚠️  Crash recovery skipped: ${err.message}`);
  }

  log('🕐 Scheduler started – checking every 15 seconds');
  runChecks();
  intervalId = setInterval(() => {
    runChecks();
  }, 15_000);
}

export function stopScheduler() {
  if (intervalId) {
    clearInterval(intervalId);
    intervalId = null;
  }
  log('⏹️  Scheduler stopped');
}

async function runChecks() {
  try {
    await processDuePosts();
    await processDueDeletes();
  } catch (err) {
    log(`❌ Scheduler error: ${err.message}`);
  }
}

async function processDuePosts() {
  const dueVideos = db.getDuePosts();
  
  for (const video of dueVideos) {
    try {
      db.updateStatus(video.id, 'posting');
      log(`📤 Posting video #${video.id}: ${video.title || video.video_url}`);
      
      const result = await postVideo(video);
      
      db.updatePostedMediaId(video.id, result.post_id);
      db.markPosted(video.id);
      log(`✅ Video ${video.id} posted to ${video.platform}. Auto-delete in ${video.delete_after_minutes} minutes.`);
    } catch (err) {
      const fullErr = `${err.message} ${err.cause?.code || ''}`;
      const isNetworkError = /fetch failed|ECONNRESET|ETIMEDOUT|ENOTFOUND|ECONNREFUSED|UND_ERR|EAI_AGAIN/i.test(fullErr);
      // YouTube quota errors are a hard daily limit — retrying within the day cannot succeed.
      const isQuotaError = /exceeded the number of videos|uploadLimitExceeded|quotaExceeded|quota.*exceed/i.test(fullErr);
      if (isNetworkError) {
        log(`🌐 Network failure for video #${video.id} — auto-retry in 3 minutes`);
      } else if (isQuotaError) {
        log(`⛔ YouTube daily upload quota reached for video #${video.id} — will NOT auto-retry (resets at midnight Pacific Time)`);
      }
      const friendly = isQuotaError
        ? 'YouTube daily upload quota exceeded for this account/project. Try again after midnight Pacific Time, or use a different Google Cloud project for this account.'
        : err.message;
      log(`❌ Failed to post video #${video.id}: ${friendly}`);
      db.markFailed(video.id, friendly, { isTransient: isNetworkError });
    }
  }
}

async function processDueDeletes() {
  const dueVideos = db.getDueDeletes();
  
  for (const video of dueVideos) {
    try {
      db.updateStatus(video.id, 'deleting');
      log(`🗑️  Deleting video #${video.id} (posted ${video.posted_at})`);
      
      await deletePost(video);
      
      db.markDeleted(video.id);
      log(`✅ Video ${video.id} deleted`);
    } catch (err) {
      log(`❌ Failed to delete video #${video.id}: ${err.message}`);
      // Don't mark as failed — it might succeed on next try
    }
  }
}
