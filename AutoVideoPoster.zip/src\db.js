import initSqlJs from 'sql.js';
import { existsSync, readFileSync, writeFileSync, mkdirSync } from 'fs';
import { join } from 'path';

const DATA_DIR = join(process.env.DB_DIR || join(process.cwd(), 'data'));
if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });

const DB_PATH = process.env.DB_PATH || join(DATA_DIR, 'videos.db');

let db;

/** Convert ISO datetime to SQLite-friendly format: "2026-08-22 21:52:00" */
function toSQLiteDate(iso) {
  if (!iso) return null;
  // "2026-08-22T21:52:00.000Z" → "2026-08-22 21:52:00"
  return iso.replace('T', ' ').replace(/\.\d{3}Z?$/, '').trim();
}

function nowSQLite() {
  return toSQLiteDate(new Date().toISOString());
}

async function initDB() {
  const SQL = await initSqlJs();

  if (existsSync(DB_PATH)) {
    const buf = readFileSync(DB_PATH);
    db = new SQL.Database(buf);
  } else {
    db = new SQL.Database();
  }

  db.run(`
    CREATE TABLE IF NOT EXISTS videos (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      video_url   TEXT NOT NULL,
      title       TEXT DEFAULT '',
      caption     TEXT DEFAULT '',
      platform    TEXT DEFAULT 'unknown',
      status      TEXT DEFAULT 'scheduled',
      scheduled_at TEXT NOT NULL,
      delete_after_minutes INTEGER DEFAULT 60,
      posted_at   TEXT,
      deleted_at  TEXT,
      error_msg   TEXT,
      created_at  TEXT DEFAULT (datetime('now'))
    );
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS settings (
      key   TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
  `);

  // Multi-account support: accounts table for thousands of accounts
  db.run(`
    CREATE TABLE IF NOT EXISTS accounts (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id       INTEGER DEFAULT NULL,
      name          TEXT NOT NULL,
      platform      TEXT NOT NULL,
      credentials   TEXT DEFAULT '{}',
      is_active     INTEGER DEFAULT 1,
      last_used_at  TEXT,
      created_at    TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id)
    );
  `);

  // Users table for multi-tenancy
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      username      TEXT UNIQUE NOT NULL,
      email         TEXT UNIQUE,
      password_hash TEXT NOT NULL,
      role          TEXT DEFAULT 'user',
      api_key       TEXT UNIQUE,
      is_active     INTEGER DEFAULT 1,
      created_at    TEXT DEFAULT (datetime('now')),
      last_login    TEXT
    );
  `);

  // API keys table for programmatic access
  db.run(`
    CREATE TABLE IF NOT EXISTS api_keys (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id       INTEGER NOT NULL,
      key_hash      TEXT NOT NULL,
      name          TEXT DEFAULT 'default',
      permissions   TEXT DEFAULT 'read,write',
      is_active     INTEGER DEFAULT 1,
      expires_at    TEXT,
      created_at    TEXT DEFAULT (datetime('now')),
      last_used_at  TEXT,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );
  `);

  // Add caption column if missing (migration for existing DBs)
  const cols = queryRows('PRAGMA table_info(videos)');
  if (!cols.some(c => c.name === 'caption')) {
    runSQL('ALTER TABLE videos ADD COLUMN caption TEXT DEFAULT \'\'');
  }
  if (!cols.some(c => c.name === 'posted_media_id')) {
    runSQL('ALTER TABLE videos ADD COLUMN posted_media_id TEXT DEFAULT NULL');
  }
  if (!cols.some(c => c.name === 'account_id')) {
    runSQL('ALTER TABLE videos ADD COLUMN account_id INTEGER DEFAULT NULL');
  }
  if (!cols.some(c => c.name === 'auto_retry_count')) {
    runSQL('ALTER TABLE videos ADD COLUMN auto_retry_count INTEGER DEFAULT 0');
  }

  // Migrate any ISO-formatted dates to SQLite format
  const allRows = queryRows('SELECT id, scheduled_at, posted_at, deleted_at, created_at FROM videos');
  for (const row of allRows) {
    const fixedScheduled = toSQLiteDate(row.scheduled_at);
    const fixedPosted = toSQLiteDate(row.posted_at);
    const fixedDeleted = toSQLiteDate(row.deleted_at);
    const fixedCreated = toSQLiteDate(row.created_at);
    runSQL(
      'UPDATE videos SET scheduled_at=?, posted_at=?, deleted_at=?, created_at=? WHERE id=?',
      [fixedScheduled, fixedPosted, fixedDeleted, fixedCreated, row.id]
    );
  }

  save();
  return db;
}

function save() {
  if (!db) return;
  const data = db.export();
  const buffer = Buffer.from(data);
  writeFileSync(DB_PATH, buffer);
}

// ─── Helpers ─────────────────────────────────────────────────────

function queryRows(sql, params = []) {
  const stmt = db.prepare(sql);
  if (params.length) stmt.bind(params);
  const rows = [];
  while (stmt.step()) {
    rows.push(stmt.getAsObject());
  }
  stmt.free();
  return rows;
}

function queryOne(sql, params = []) {
  const rows = queryRows(sql, params);
  return rows.length > 0 ? rows[0] : undefined;
}

function runSQL(sql, params = []) {
  db.run(sql, params);
  save();
}

function detectPlatform(url) {
  if (!url) return 'unknown';
  const u = url.toLowerCase();
  if (u.includes('youtube.com') || u.includes('youtu.be')) return 'youtube';
  if (u.includes('vimeo.com')) return 'vimeo';
  if (u.includes('tiktok.com')) return 'tiktok';
  if (u.includes('twitter.com') || u.includes('x.com')) return 'twitter';
  if (u.includes('instagram.com')) return 'instagram';
  if (u.includes('facebook.com')) return 'facebook';
  if (u.includes('reddit.com')) return 'reddit';
  return 'other';
}

// ─── Public API ──────────────────────────────────────────────────

export async function init() {
  await initDB();
}

export function addVideo({ video_url, title = '', caption = '', platform, scheduled_at, delete_after_minutes = 60, account_id = null }) {
  platform = platform || detectPlatform(video_url);
  runSQL(
    `INSERT INTO videos (video_url, title, caption, platform, scheduled_at, delete_after_minutes, account_id)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [video_url, title, caption, platform, toSQLiteDate(scheduled_at), delete_after_minutes, account_id]
  );
  const row = queryOne('SELECT * FROM videos ORDER BY id DESC LIMIT 1');
  return row;
}

export function getVideo(id) {
  return queryOne('SELECT * FROM videos WHERE id = ?', [id]);
}

export function getAllVideos() {
  return queryRows('SELECT * FROM videos ORDER BY created_at DESC');
}

export function getDuePosts() {
  return queryRows(`
    SELECT * FROM videos
    WHERE status = 'scheduled'
      AND scheduled_at <= datetime('now')
    ORDER BY scheduled_at ASC
  `);
}

export function getDueDeletes() {
  return queryRows(`
    SELECT * FROM videos
    WHERE status = 'posted'
      AND delete_after_minutes IS NOT NULL
      AND delete_after_minutes > 0
      AND posted_at IS NOT NULL
      AND datetime(posted_at, '+' || delete_after_minutes || ' minutes') <= datetime('now')
  `);
}

export function markPosted(id) {
  runSQL(`UPDATE videos SET status = 'posted', posted_at = ? WHERE id = ?`, [nowSQLite(), id]);
  return getVideo(id);
}

export function markDeleted(id) {
  runSQL(`UPDATE videos SET status = 'deleted', deleted_at = ? WHERE id = ?`, [nowSQLite(), id]);
  return getVideo(id);
}

export function markFailed(id, errorMsg, { isTransient = false } = {}) {
  if (isTransient) {
    // Network failures: auto-requeue so the post can ride out connectivity
    // blackouts without human intervention. Give up after 5 tries, then fail
    // permanently so a dead URL doesn't churn forever.
    const row = queryRows('SELECT auto_retry_count FROM videos WHERE id = ?', [id])[0] || {};
    const count = (row.auto_retry_count || 0) + 1;
    if (count <= 5) {
      runSQL(
        `UPDATE videos SET status = 'scheduled', scheduled_at = datetime('now', '+3 minutes'), error_msg = ?, auto_retry_count = ? WHERE id = ?`,
        [`Retrying (network): ${errorMsg} (attempt ${count}/5)`, count, id]
      );
      return getVideo(id);
    }
    runSQL(`UPDATE videos SET status = 'failed', error_msg = ? WHERE id = ?`, [errorMsg, id]);
    return getVideo(id);
  }
  runSQL(`UPDATE videos SET status = 'failed', error_msg = ? WHERE id = ?`, [errorMsg, id]);
  return getVideo(id);
}

export function updateStatus(id, status) {
  runSQL(`UPDATE videos SET status = ? WHERE id = ?`, [status, id]);
  return getVideo(id);
}

// Restore a 'posted' state without touching posted_at — used by crash recovery
// so an interrupted auto-delete re-fires immediately instead of resetting its timer.
// Videos frozen in a transient state (server crashed mid-upload/mid-delete)
export function getStuckVideos() {
  return queryRows("SELECT id, status, posted_media_id FROM videos WHERE status IN ('posting','deleting')");
}

export function restorePosted(id) {
  runSQL(`UPDATE videos SET status = 'posted' WHERE id = ?`, [id]);
  return getVideo(id);
}

export function updatePostedMediaId(id, mediaId) {
  runSQL('UPDATE videos SET posted_media_id = ? WHERE id = ?', [mediaId, id]);
  return getVideo(id);
}

export function retryVideo(id) {
  runSQL(
    `UPDATE videos SET status = 'scheduled', error_msg = NULL, posted_at = NULL, deleted_at = NULL, auto_retry_count = 0 WHERE id = ?`,
    [id]
  );
  return getVideo(id);
}

export function removeVideo(id) {
  runSQL('DELETE FROM videos WHERE id = ?', [id]);
}

export function getStats() {
  return queryRows('SELECT status, COUNT(*) as count FROM videos GROUP BY status');
}

// ─── Analytics ─────────────────────────────────────────────────

export function getWeeklyHistory() {
  // Posts grouped by day for the last 7 days
  return queryRows(`
    SELECT date(scheduled_at) as day, status, COUNT(*) as count
    FROM videos
    WHERE scheduled_at >= datetime('now', '-7 days')
    GROUP BY date(scheduled_at), status
    ORDER BY day ASC
  `);
}

export function getMonthlyHistory() {
  // Posts grouped by day for the last 30 days
  return queryRows(`
    SELECT date(scheduled_at) as day, status, COUNT(*) as count
    FROM videos
    WHERE scheduled_at >= datetime('now', '-30 days')
    GROUP BY date(scheduled_at), status
    ORDER BY day ASC
  `);
}

export function getSuccessRates() {
  // Overall success rate and per-platform success rate
  const overall = queryOne(`
    SELECT
      COUNT(*) as total,
      SUM(CASE WHEN status = 'posted' OR status = 'deleted' THEN 1 ELSE 0 END) as succeeded,
      SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
      SUM(CASE WHEN status = 'scheduled' THEN 1 ELSE 0 END) as pending,
      SUM(CASE WHEN status = 'posting' OR status = 'deleting' THEN 1 ELSE 0 END) as in_progress
    FROM videos
  `);

  const byPlatform = queryRows(`
    SELECT
      platform,
      COUNT(*) as total,
      SUM(CASE WHEN status = 'posted' OR status = 'deleted' THEN 1 ELSE 0 END) as succeeded,
      SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed
    FROM videos
    GROUP BY platform
  `);

  return { overall, byPlatform };
}

export function getOptimalTimes() {
  // Hour-of-day breakdown for posted videos
  return queryRows(`
    SELECT
      CAST(strftime('%H', posted_at) AS INTEGER) as hour,
      COUNT(*) as post_count,
      SUM(CASE WHEN error_msg IS NULL THEN 1 ELSE 0 END) as success_count
    FROM videos
    WHERE posted_at IS NOT NULL
    GROUP BY hour
    ORDER BY hour ASC
  `);
}

export function getDayOfWeekStats() {
  // Day-of-week breakdown for scheduled posts
  return queryRows(`
    SELECT
      CAST(strftime('%w', scheduled_at) AS INTEGER) as day_of_week,
      COUNT(*) as total,
      SUM(CASE WHEN status = 'posted' OR status = 'deleted' THEN 1 ELSE 0 END) as succeeded,
      SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed
    FROM videos
    GROUP BY day_of_week
    ORDER BY day_of_week ASC
  `);
}

export function getRecentActivity() {
  // Last 50 videos with status and timestamps
  return queryRows(`
    SELECT id, title, video_url, platform, status, scheduled_at, posted_at, deleted_at, error_msg
    FROM videos
    ORDER BY created_at DESC
    LIMIT 50
  `);
}

export function getAnalyticsOverview() {
  const totalVideos = queryOne('SELECT COUNT(*) as count FROM videos');
  const avgDaily = queryOne(`
    SELECT AVG(daily_count) as avg FROM (
      SELECT date(scheduled_at) as day, COUNT(*) as daily_count
      FROM videos
      WHERE scheduled_at >= datetime('now', '-7 days')
      GROUP BY date(scheduled_at)
    )
  `);
  const avgDeleteTime = queryOne(`
    SELECT AVG(
      (julianday(deleted_at) - julianday(posted_at)) * 24 * 60
    ) as avg_minutes
    FROM videos
    WHERE posted_at IS NOT NULL AND deleted_at IS NOT NULL
  `);
  const lastPost = queryOne(`
    SELECT posted_at FROM videos
    WHERE posted_at IS NOT NULL
    ORDER BY posted_at DESC LIMIT 1
  `);
  const nextScheduled = queryOne(`
    SELECT scheduled_at, title FROM videos
    WHERE status = 'scheduled' AND scheduled_at > datetime('now')
    ORDER BY scheduled_at ASC LIMIT 1
  `);

  return {
    totalVideos: totalVideos?.count || 0,
    avgDailyPosts: avgDaily?.avg ? Math.round(avgDaily.avg * 10) / 10 : 0,
    avgDeleteMinutes: avgDeleteTime?.avg_minutes ? Math.round(avgDeleteTime.avg_minutes) : null,
    lastPost: lastPost?.posted_at || null,
    nextScheduled: nextScheduled || null,
  };
}

// ─── Settings ──────────────────────────────────────────────────

export function getSettings() {
  const rows = queryRows('SELECT key, value FROM settings');
  const map = {};
  for (const r of rows) map[r.key] = r.value;
  return map;
}

export function getSetting(key) {
  const row = queryOne('SELECT value FROM settings WHERE key = ?', [key]);
  return row ? row.value : null;
}

export function setSetting(key, value) {
  runSQL('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', [key, value]);
}

export function setSettings(obj) {
  for (const [key, value] of Object.entries(obj)) {
    runSQL('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', [key, value]);
  }
}

export function deleteSetting(key) {
  runSQL('DELETE FROM settings WHERE key = ?', [key]);
}

// ─── Accounts ─────────────────────────────────────────────────

export function addAccount({ name, platform, credentials = '{}' }) {
  runSQL(
    `INSERT INTO accounts (name, platform, credentials) VALUES (?, ?, ?)`,
    [name, platform, credentials]
  );
  return queryOne('SELECT * FROM accounts ORDER BY id DESC LIMIT 1');
}

export function getAccount(id) {
  return queryOne('SELECT * FROM accounts WHERE id = ?', [id]);
}

export function getAllAccounts() {
  return queryRows('SELECT * FROM accounts ORDER BY platform, name');
}

export function getAccountsByPlatform(platform) {
  return queryRows('SELECT * FROM accounts WHERE platform = ? AND is_active = 1', [platform]);
}

export function getActiveAccounts() {
  return queryRows('SELECT * FROM accounts WHERE is_active = 1 ORDER BY platform, name');
}

export function updateAccount(id, { name, platform, credentials, is_active }) {
  const account = getAccount(id);
  if (!account) return null;
  runSQL(
    `UPDATE accounts SET name = ?, platform = ?, credentials = ?, is_active = ? WHERE id = ?`,
    [name || account.name, platform || account.platform, credentials || account.credentials, is_active ?? account.is_active, id]
  );
  return getAccount(id);
}

export function deleteAccount(id) {
  runSQL('DELETE FROM accounts WHERE id = ?', [id]);
}

export function markAccountUsed(id) {
  runSQL('UPDATE accounts SET last_used_at = ? WHERE id = ?', [nowSQLite(), id]);
}

export function getAccountStats() {
  return queryRows(`
    SELECT platform, COUNT(*) as total, SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active
    FROM accounts
    GROUP BY platform
  `);
}

// ─── Users ───────────────────────────────────────────────────

export function addUser({ username, email, password_hash, role = 'user' }) {
  runSQL(
    `INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, ?)`,
    [username, email, password_hash, role]
  );
  return queryOne('SELECT id, username, email, role, created_at FROM users ORDER BY id DESC LIMIT 1');
}

export function getUser(id) {
  return queryOne('SELECT id, username, email, role, is_active, created_at, last_login FROM users WHERE id = ?', [id]);
}

export function getUserByUsername(username) {
  return queryOne('SELECT * FROM users WHERE username = ?', [username]);
}

export function getUserByEmail(email) {
  return queryOne('SELECT * FROM users WHERE email = ?', [email]);
}

export function getUserByApiKey(apiKey) {
  return queryOne('SELECT * FROM users WHERE api_key = ? AND is_active = 1', [apiKey]);
}

export function updateUser(id, { username, email, role, is_active, last_login, api_key }) {
  const user = getUser(id);
  if (!user) return null;
  runSQL(
    `UPDATE users SET username=?, email=?, role=?, is_active=?, last_login=?, api_key=? WHERE id=?`,
    [username ?? user.username, email ?? user.email, role ?? user.role, is_active ?? user.is_active, last_login ?? user.last_login, api_key ?? user.api_key, id]
  );
  return getUser(id);
}

export function updateLastLogin(id) {
  runSQL('UPDATE users SET last_login = ? WHERE id = ?', [nowSQLite(), id]);
}

export function getAllUsers() {
  return queryRows('SELECT id, username, email, role, is_active, created_at, last_login FROM users ORDER BY created_at DESC');
}

export function deleteUser(id) {
  runSQL('DELETE FROM users WHERE id = ?', [id]);
}

// ─── API Keys ───────────────────────────────────────────────

export function addApiKey({ user_id, key_hash, name = 'default', permissions = 'read,write', expires_at }) {
  runSQL(
    `INSERT INTO api_keys (user_id, key_hash, name, permissions, expires_at) VALUES (?, ?, ?, ?, ?)`,
    [user_id, key_hash, name, permissions, expires_at]
  );
  return queryOne('SELECT * FROM api_keys ORDER BY id DESC LIMIT 1');
}

export function getApiKey(keyHash) {
  return queryOne('SELECT * FROM api_keys WHERE key_hash = ? AND is_active = 1', [keyHash]);
}

export function getApiKeysByUser(userId) {
  return queryRows('SELECT id, name, permissions, is_active, expires_at, created_at, last_used_at FROM api_keys WHERE user_id = ?', [userId]);
}

export function deleteApiKey(id) {
  runSQL('DELETE FROM api_keys WHERE id = ?', [id]);
}

// ─── User-scoped queries ───────────────────────────────────

export function getUserVideos(userId) {
  return queryRows('SELECT * FROM videos WHERE user_id = ? ORDER BY created_at DESC', [userId]);
}

export function addUserVideo({ user_id, video_url, title = '', caption = '', platform, scheduled_at, delete_after_minutes = 60, account_id }) {
  platform = platform || detectPlatform(video_url);
  runSQL(
    `INSERT INTO videos (user_id, video_url, title, caption, platform, scheduled_at, delete_after_minutes, account_id)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [user_id, video_url, title, caption, platform, toSQLiteDate(scheduled_at), delete_after_minutes, account_id]
  );
  return queryOne('SELECT * FROM videos ORDER BY id DESC LIMIT 1');
}

export function getUserStats(userId) {
  return queryRows('SELECT status, COUNT(*) as count FROM videos WHERE user_id = ? GROUP BY status', [userId]);
}

export function getUserAccounts(userId) {
  return queryRows('SELECT * FROM accounts WHERE user_id = ? AND is_active = 1 ORDER BY platform, name', [userId]);
}

// ─── YouTube quota tracking ─────────────────────────────────────
// YouTube counts quota per Google Cloud project (OAuth client_id), shared by
// all channels authenticating through it. Default project allowance allows
// ~6 uploads/day (10,000 units; each upload costs 1,600).
const YT_QUOTA_UPLOADS_PER_PROJECT = 6;

// ─── Per-account YouTube quota tracker ──────────────────────────
// YouTube's default Google Cloud project allows ~6 uploads/day per project.
// Each connected account gets its own tracker.
const YT_DAILY_UPLOAD_LIMIT = 6;

export function getQuotaStatus() {
  const dailyLimit = YT_DAILY_UPLOAD_LIMIT;
  const accounts = queryRows("SELECT id, name FROM accounts WHERE platform = 'youtube' AND is_active = 1 ORDER BY name");
  const now = new Date();
  const utcMidnight = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));

  const posted = queryRows(`
    SELECT account_id, COUNT(*) as count FROM videos
    WHERE status IN ('posted', 'deleted')
      AND posted_at >= ?
    GROUP BY account_id
  `, [utcMidnight.toISOString().replace('T', ' ').slice(0, 19)]);
  const postedByAccount = new Map(posted.map(r => [Number(r.account_id), r.count]));

  const pacific = new Date(now.toLocaleString('en-US', { timeZone: 'America/Los_Angeles' }));
  const resetsAt = new Date(pacific.getFullYear(), pacific.getMonth(), pacific.getDate()).getTime() + 24 * 60 * 60 * 1000;

  const accounts_out = accounts.map(a => {
    const used = postedByAccount.get(a.id) || 0;
    return {
      id: a.id,
      name: a.name,
      used,
      limit: dailyLimit,
      remaining: Math.max(0, dailyLimit - used),
      pct: Math.min(100, Math.round((used / dailyLimit) * 100)),
    };
  });

  return { accounts: accounts_out, resets_at_utc: new Date(resetsAt).toISOString(), daily_limit: dailyLimit };
}

export default { init, addVideo, getVideo, getAllVideos, getDuePosts, getDueDeletes, markPosted, markDeleted, markFailed, updateStatus, updatePostedMediaId, restorePosted, retryVideo, removeVideo, getStats, getSettings, getSetting, setSetting, setSettings, deleteSetting, addAccount, getAccount, getAllAccounts, getAccountsByPlatform, getActiveAccounts, updateAccount, deleteAccount, markAccountUsed, getAccountStats, getStuckVideos, getQuotaStatus, addUser, getUser, getUserByUsername, getUserByEmail, getUserByApiKey, updateUser, updateLastLogin, getAllUsers, deleteUser, addApiKey, getApiKey, getApiKeysByUser, deleteApiKey, getUserVideos, addUserVideo, getUserStats, getUserAccounts };
