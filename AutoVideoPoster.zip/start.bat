@echo off
title Auto Video Poster
color 0A

echo.
echo  ╔══════════════════════════════════════════════════════════╗
echo  ║           AUTO VIDEO POSTER - STARTER                  ║
echo  ╚══════════════════════════════════════════════════════════╝
echo.

:: Check if Node.js is installed
echo [1/4] Checking Node.js installation...
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  ❌ Node.js is not installed!
    echo.
    echo  Please install Node.js from: https://nodejs.org
    echo  Download the LTS version and run the installer.
    echo.
    echo  After installing, run this script again.
    pause
    exit /b 1
)
for /f "tokens=*" %%i in ('node --version') do set NODE_VER=%%i
echo  ✅ Node.js found: %NODE_VER%

:: Check if npm is installed
echo [2/4] Checking npm installation...
npm --version >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  ❌ npm is not installed!
    echo  Please reinstall Node.js from: https://nodejs.org
    pause
    exit /b 1
)
for /f "tokens=*" %%i in ('npm --version') do set NPM_VER=%%i
echo  ✅ npm found: v%NPM_VER%

:: Install dependencies
echo [3/4] Installing dependencies (this may take a minute)...
if not exist "node_modules" (
    call npm install --production
    if %errorlevel% neq 0 (
        echo.
        echo  ❌ Failed to install dependencies!
        echo  Please check your internet connection and try again.
        pause
        exit /b 1
    )
    echo  ✅ Dependencies installed successfully!
) else (
    echo  ✅ Dependencies already installed!
)

:: Start the server
echo [4/4] Starting Auto Video Poster server...
echo.
echo  ╔══════════════════════════════════════════════════════════╗
echo  ║  Server starting on http://localhost:5500               ║
echo  ║  Press Ctrl+C to stop the server                       ║
echo  ╚══════════════════════════════════════════════════════════╝
echo.

:: Open browser after 2 second delay
start "" /b cmd /c "timeout /t 2 /nobreak >nul && start http://localhost:5500"

:: Start the server
set PORT=5500
node src/index.js

pause
