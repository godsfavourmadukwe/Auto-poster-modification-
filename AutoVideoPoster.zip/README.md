# Auto Video Poster 🎬

Automatic video scheduler that posts to YouTube, Instagram, TikTok, and Snapchat — then auto-deletes after a set time.

## Quick Start

### Windows
1. Make sure [Node.js](https://nodejs.org) is installed (LTS version)
2. Double-click `start.bat`
3. The server starts and opens your browser automatically

### Linux / Mac
```bash
chmod +x start.sh
./start.sh
```

### Manual (any OS)
```bash
npm install
PORT=5500 node src/index.js
```
Then open **http://localhost:5500** in your browser.

## Global Access (Cross-Country)

Access your poster from any device anywhere in the world using Cloudflare Tunnel:

### Windows
```bash
# Install cloudflared first
winget install cloudflare.cloudflared

# Then run
start-tunnel.bat
```

### Linux / Mac
```bash
# Install cloudflared
# macOS:
brew install cloudflared
# Linux:
curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o cloudflared
chmod +x cloudflared
sudo mv cloudflared /usr/local/bin/

# Then run
chmod +x start-tunnel.sh
./start-tunnel.sh
```

The tunnel gives you a public URL (like `https://abc-xyz.trycloudflare.com`) that works from any device, anywhere in the world. Share it with your other devices!

## Features

- **Schedule videos** with date/time picker
- **Multi-platform**: YouTube, Instagram, TikTok, Snapchat
- **One-click OAuth** — connect accounts with a single button
- **Auto-delete** — videos removed after configurable time
- **Cross-platform posting** — paste a TikTok link, post to YouTube
- **Multi-account support** — manage thousands of accounts
- **Activity log** — track all posts, deletes, and errors
- **Analytics dashboard** — view posting history and success rates
- **Global access** — Cloudflare Tunnel for cross-country control

## Platform Setup

### YouTube
1. Go to [Google Cloud Console](https://console.cloud.google.com/apis/credentials)
2. Create OAuth 2.0 Client ID → Desktop App
3. Download JSON → save as `client_secret.json` in project root
4. In Settings → YouTube → click **🔗 Connect YouTube (Auto)**

### Instagram
1. Go to [Facebook Developers](https://developers.facebook.com/apps)
2. Create app → add Instagram Graph API
3. Set Redirect URI: `http://localhost:5500/api/instagram/callback`
4. In Settings → Instagram → click **🔗 Connect Instagram (Auto)**

### TikTok
1. Go to [TikTok Developers](https://developers.tiktok.com)
2. Create app → add Login Kit + Content Posting API
3. Set Redirect URI: `http://localhost:5500/api/tiktok/callback`
4. In Settings → TikTok → click **🔗 Connect TikTok (Auto)**

### Snapchat
1. Go to [Snapchat Business API](https://businessapi.snapchat.com)
2. Create app → add Snapchat Marketing API
3. Set Redirect URI: `http://localhost:5500/api/snapchat/callback`
4. In Settings → Snapchat → click **🔗 Connect Snapchat (Auto)**

## Supported Video URLs

| Source | Works? |
|--------|--------|
| Direct .mp4 links | ✅ Best option |
| Google Drive links | ✅ Auto-converts |
| Dropbox links | ✅ Auto-converts |
| TikTok links | ✅ Extracts video |
| Reddit videos | ✅ Extracts video |
| Twitter/X videos | ⚠️ Requires auth |
| YouTube links | ❌ YouTube blocks re-upload |

## Tech Stack

- **Backend**: Node.js + Express
- **Database**: SQLite (sql.js)
- **Frontend**: Vanilla HTML/CSS/JS
- **Theme**: Cosmic dark mode
- **Tunnel**: Cloudflare Tunnel (optional, for global access)

## Project Structure

```
auto-video-poster/
├── start.bat           # Windows one-click launcher
├── start.sh            # Linux/Mac one-click launcher
├── start-tunnel.bat    # Windows + Cloudflare Tunnel
├── start-tunnel.sh     # Linux/Mac + Cloudflare Tunnel
├── package.json        # Dependencies
├── client_secret.json  # YouTube OAuth (you provide)
├── src/
│   ├── index.js        # Server entry point
│   ├── routes.js       # API routes + OAuth flows
│   ├── scheduler.js    # Video posting engine
│   ├── db.js           # SQLite database
│   ├── utils.js        # Helper functions
│   └── public/
│       └── index.html  # Frontend UI
└── data/
    └── videos.db       # Database (auto-created)
```

## License

MIT
