import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import crypto from 'crypto';
import dns from 'dns';
import router from './routes.js';
import authRouter from './routes/auth.js';
import { startScheduler, stopScheduler } from './scheduler.js';
import { log } from './utils.js';
import { init as initDB } from './db.js';

// Force IPv4-first DNS resolution — many Windows machines have broken or
// heavily throttled IPv6 routes, and Node's default (verbatim) order tries
// AAAA records first, causing UND_ERR_CONNECT_TIMEOUT on large uploads.
dns.setDefaultResultOrder('ipv4first');

const __dirname = dirname(fileURLToPath(import.meta.url));

// ─── Environment Configuration ─────────────────────────────────
const PORT = parseInt(process.env.PORT || '5500', 10);
const HOST = process.env.HOST || '0.0.0.0';
const NODE_ENV = process.env.NODE_ENV || 'development';
const CORS_ORIGINS = process.env.CORS_ORIGINS || '*';

// ─── Rate Limiting (in-memory, production should use Redis) ────
const rateLimitStore = new Map();
const RATE_LIMIT_WINDOW = parseInt(process.env.RATE_LIMIT_WINDOW_MS || '60000', 10);
const RATE_LIMIT_MAX = parseInt(process.env.RATE_LIMIT_MAX || '100', 10);

function rateLimit(req, res, next) {
  const ip = req.ip || req.connection?.remoteAddress || 'unknown';
  const now = Date.now();
  const windowStart = now - RATE_LIMIT_WINDOW;
  
  if (!rateLimitStore.has(ip)) {
    rateLimitStore.set(ip, []);
  }
  
  const requests = rateLimitStore.get(ip).filter(t => t > windowStart);
  rateLimitStore.set(ip, requests);
  
  if (requests.length >= RATE_LIMIT_MAX) {
    return res.status(429).json({ error: 'Too many requests. Please try again later.' });
  }
  
  requests.push(now);
  
  // Set rate limit headers
  res.set('X-RateLimit-Limit', String(RATE_LIMIT_MAX));
  res.set('X-RateLimit-Remaining', String(RATE_LIMIT_MAX - requests.length));
  res.set('X-RateLimit-Reset', String(Math.ceil((windowStart + RATE_LIMIT_WINDOW) / 1000)));
  
  next();
}

// Clean up old rate limit entries every 5 minutes
setInterval(() => {
  const now = Date.now();
  const windowStart = now - RATE_LIMIT_WINDOW;
  for (const [ip, requests] of rateLimitStore) {
    const valid = requests.filter(t => t > windowStart);
    if (valid.length === 0) {
      rateLimitStore.delete(ip);
    } else {
      rateLimitStore.set(ip, valid);
    }
  }
}, 300000);

// ─── Security Headers ──────────────────────────────────────────
function securityHeaders(req, res, next) {
  // Prevent clickjacking
  res.set('X-Frame-Options', 'DENY');
  // Prevent MIME sniffing
  res.set('X-Content-Type-Options', 'nosniff');
  // XSS protection
  res.set('X-XSS-Protection', '1; mode=block');
  // Referrer policy
  res.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  // HSTS (only in production with HTTPS)
  if (NODE_ENV === 'production') {
    res.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  }
  // Content Security Policy
  res.set('Content-Security-Policy', "default-src 'self' 'unsafe-inline' 'unsafe-eval' https:; img-src 'self' data: https:; font-src 'self' data:;");
  next();
}

// ─── CORS ──────────────────────────────────────────────────────
function corsMiddleware(req, res, next) {
  const origin = req.headers.origin;
  
  if (CORS_ORIGINS === '*') {
    res.set('Access-Control-Allow-Origin', '*');
  } else if (origin && CORS_ORIGINS.split(',').map(o => o.trim()).includes(origin)) {
    res.set('Access-Control-Allow-Origin', origin);
  }
  
  res.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
  res.set('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-API-Key');
  res.set('Access-Control-Allow-Credentials', 'true');
  res.set('Access-Control-Max-Age', '86400');
  
  if (req.method === 'OPTIONS') {
    return res.status(204).end();
  }
  
  next();
}

// ─── Request Logging ───────────────────────────────────────────
function requestLogger(req, res, next) {
  const start = Date.now();
  const { method, url } = req;
  
  res.on('finish', () => {
    const duration = Date.now() - start;
    const status = res.statusCode;
    const level = status >= 400 ? 'warn' : 'info';
    
    if (url !== '/api/health' && url !== '/favicon.ico') {
      log(`${method} ${url} ${status} ${duration}ms`, level);
    }
  });
  
  next();
}

// ─── Cookie Parser (simple) ────────────────────────────────────
function cookieParser(req, res, next) {
  req.cookies = {};
  const cookieHeader = req.headers.cookie;
  if (cookieHeader) {
    cookieHeader.split(';').forEach(cookie => {
      const [name, ...rest] = cookie.split('=');
      req.cookies[name.trim()] = rest.join('=').trim();
    });
  }
  next();
}

async function main() {
  // Initialize the database first (async for sql.js WASM load)
  await initDB();
  log('💾 Database initialized');

  const app = express();

  // ─── Trust proxy (for rate limiting behind reverse proxy) ────
  app.set('trust proxy', 1);

  // ─── Core Middleware ─────────────────────────────────────────
  app.use(cookieParser);
  app.use(express.json({ limit: '10mb' }));
  app.use(securityHeaders);
  app.use(corsMiddleware);
  app.use(rateLimit);
  app.use(requestLogger);

  // ─── Health Check (no auth required) ────────────────────────
  app.get('/api/health', (req, res) => {
    const uptime = process.uptime();
    const memUsage = process.memoryUsage();
    
    res.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      uptime: Math.floor(uptime),
      memory: {
        rss: Math.round(memUsage.rss / 1024 / 1024) + 'MB',
        heap: Math.round(memUsage.heapUsed / 1024 / 1024) + 'MB',
      },
      version: '1.0.0',
      env: NODE_ENV,
    });
  });

  // ─── Metrics Endpoint ───────────────────────────────────────
  app.get('/api/metrics', (req, res) => {
    const memUsage = process.memoryUsage();
    const cpuUsage = process.cpuUsage();
    
    res.json({
      uptime: process.uptime(),
      memory: memUsage,
      cpu: cpuUsage,
      pid: process.pid,
      nodeVersion: process.version,
      platform: process.platform,
      arch: process.arch,
    });
  });

  // ─── Auth Routes (no auth required) ─────────────────────────
  app.use('/api/auth', authRouter);

  // ─── API routes (must come BEFORE static to avoid SPA fallback catching /api/*) ──
  app.use(router);

  // ─── Static files ───────────────────────────────────────────
  app.use(express.static(join(__dirname, 'public')));

  // ─── SPA fallback ────────────────────────────────────────────
  app.get('*', (req, res) => {
    res.sendFile(join(__dirname, 'public', 'index.html'));
  });

  // ─── Error Handler ──────────────────────────────────────────
  app.use((err, req, res, next) => {
    log(`❌ Error: ${err.message}`, 'error');
    console.error(err.stack);
    
    res.status(err.status || 500).json({
      error: NODE_ENV === 'production' ? 'Internal server error' : err.message,
    });
  });

  // ─── Start Server ───────────────────────────────────────────
  const server = app.listen(PORT, HOST, () => {
    log('🚀 Auto Video Poster started');
    log(`   Server: http://${HOST}:${PORT}`);
    log(`   Health: http://${HOST}:${PORT}/api/health`);
    log(`   Environment: ${NODE_ENV}`);
    startScheduler();
  });

  // ─── Graceful Shutdown ──────────────────────────────────────
  const shutdown = async (signal) => {
    log(`\n🛑 ${signal} received. Starting graceful shutdown...`);
    
    // Stop accepting new connections
    server.close(() => {
      log('📡 HTTP server closed');
    });
    
    // Stop the scheduler
    stopScheduler();
    log('⏰ Scheduler stopped');
    
    // Close database
    try {
      const { default: db } = await import('./db.js');
      // Database is sql.js - save to disk
      log('💾 Database saved');
    } catch (e) {
      log('⚠️  Database close error: ' + e.message, 'warn');
    }
    
    log('👋 Graceful shutdown complete');
    process.exit(0);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));

  // Handle uncaught exceptions
  process.on('uncaughtException', (err) => {
    log(`💥 Uncaught Exception: ${err.message}`, 'error');
    console.error(err.stack);
    // Don't exit in production - let the process manager handle restarts
    if (NODE_ENV !== 'production') {
      process.exit(1);
    }
  });

  process.on('unhandledRejection', (reason) => {
    log(`💥 Unhandled Rejection: ${reason}`, 'error');
    console.error(reason);
  });
}

main().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
