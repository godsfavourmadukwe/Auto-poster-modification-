import { Router } from 'express';
import crypto from 'crypto';
import * as db from '../db.js';
import { signJWT, requireAuth, hashPassword, verifyPassword, generateApiKey } from '../auth.js';
import { log } from '../utils.js';

const router = Router();

// ─── POST /api/auth/register – Create new account ─────────────
router.post('/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;
    
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password are required' });
    }
    
    if (username.length < 3 || username.length > 30) {
      return res.status(400).json({ error: 'Username must be 3-30 characters' });
    }
    
    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }
    
    // Check if username exists
    const existing = db.getUserByUsername(username);
    if (existing) {
      return res.status(409).json({ error: 'Username already taken' });
    }
    
    // Check if email exists
    if (email) {
      const existingEmail = db.getUserByEmail(email);
      if (existingEmail) {
        return res.status(409).json({ error: 'Email already registered' });
      }
    }
    
    // Create user
    const passwordHash = hashPassword(password);
    const isFirstUser = !db.getAllUsers().length;
    const user = db.addUser({
      username,
      email: email || null,
      password_hash: passwordHash,
      role: isFirstUser ? 'admin' : 'user', // First user is admin
    });
    
    // Generate API key for the user
    const apiKey = generateApiKey();
    db.updateUser(user.id, { api_key: apiKey });
    
    // Generate JWT
    const token = signJWT({ id: user.id, username: user.username, role: user.role });
    
    log(`👤 New user registered: ${username} (${isFirstUser ? 'admin' : 'user'})`);
    
    res.status(201).json({
      message: 'Account created successfully',
      user: { id: user.id, username: user.username, email: user.email, role: user.role },
      token,
      api_key: apiKey,
    });
  } catch (err) {
    log(`❌ Registration error: ${err.message}`, 'error');
    res.status(500).json({ error: 'Registration failed' });
  }
});

// ─── POST /api/auth/login – Authenticate user ────────────────
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password are required' });
    }
    
    // Find user by username or email
    let user = db.getUserByUsername(username);
    if (!user && username.includes('@')) {
      user = db.getUserByEmail(username);
    }
    
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    if (!user.is_active) {
      return res.status(403).json({ error: 'Account is disabled' });
    }
    
    // Verify password
    if (!verifyPassword(password, user.password_hash)) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    // Update last login
    db.updateLastLogin(user.id);
    
    // Generate JWT
    const token = signJWT({ id: user.id, username: user.username, role: user.role });
    
    log(`🔐 User logged in: ${user.username}`);
    
    res.json({
      message: 'Login successful',
      user: { id: user.id, username: user.username, email: user.email, role: user.role },
      token,
      api_key: user.api_key,
    });
  } catch (err) {
    log(`❌ Login error: ${err.message}`, 'error');
    res.status(500).json({ error: 'Login failed' });
  }
});

// ─── GET /api/auth/me – Get current user profile ──────────────
router.get('/me', requireAuth, (req, res) => {
  const user = db.getUser(req.user.id);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  const apiKeys = db.getApiKeysByUser(user.id);
  
  res.json({
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      created_at: user.created_at,
      last_login: user.last_login,
    },
    api_keys: apiKeys,
  });
});

// ─── PUT /api/auth/profile – Update profile ───────────────────
router.put('/profile', requireAuth, (req, res) => {
  const { email, current_password, new_password } = req.body;
  const user = db.getUserByUsername(req.user.username);
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  // If changing password, verify current password
  if (new_password) {
    if (!current_password) {
      return res.status(400).json({ error: 'Current password required' });
    }
    if (!verifyPassword(current_password, user.password_hash)) {
      return res.status(401).json({ error: 'Current password is incorrect' });
    }
    if (new_password.length < 6) {
      return res.status(400).json({ error: 'New password must be at least 6 characters' });
    }
    const newHash = hashPassword(new_password);
    db.runSQL('UPDATE users SET password_hash = ? WHERE id = ?', [newHash, user.id]);
  }
  
  // Update email
  if (email && email !== user.email) {
    const existingEmail = db.getUserByEmail(email);
    if (existingEmail && existingEmail.id !== user.id) {
      return res.status(409).json({ error: 'Email already in use' });
    }
    db.updateUser(user.id, { email });
  }
  
  const updated = db.getUser(user.id);
  res.json({ message: 'Profile updated', user: updated });
});

// ─── POST /api/auth/api-keys – Create API key ────────────────
router.post('/api-keys', requireAuth, (req, res) => {
  const { name, permissions, expires_in_days } = req.body;
  
  const rawKey = generateApiKey();
  const keyHash = crypto.createHash('sha256').update(rawKey).digest('hex');
  
  let expiresAt = null;
  if (expires_in_days) {
    const d = new Date();
    d.setDate(d.getDate() + expires_in_days);
    expiresAt = d.toISOString();
  }
  
  const apiKey = db.addApiKey({
    user_id: req.user.id,
    key_hash: keyHash,
    name: name || 'default',
    permissions: permissions || 'read,write',
    expires_at: expiresAt,
  });
  
  log(`🔑 API key created: ${name || 'default'} for user ${req.user.username}`);
  
  res.status(201).json({
    message: 'API key created',
    key: rawKey, // Only shown once!
    id: apiKey.id,
    name: apiKey.name,
    permissions: apiKey.permissions,
    expires_at: apiKey.expires_at,
  });
});

// ─── DELETE /api/auth/api-keys/:id – Revoke API key ──────────
router.delete('/api-keys/:id', requireAuth, (req, res) => {
  const key = db.getApiKey(req.params.id);
  if (!key || key.user_id !== req.user.id) {
    return res.status(404).json({ error: 'API key not found' });
  }
  
  db.deleteApiKey(req.params.id);
  log(`🔑 API key revoked: ${key.name}`);
  
  res.json({ message: 'API key revoked' });
});

// ─── GET /api/auth/users – List all users (admin only) ────────
router.get('/users', requireAuth, (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  
  const users = db.getAllUsers();
  res.json(users);
});

// ─── PUT /api/auth/users/:id – Update user (admin only) ───────
router.put('/users/:id', requireAuth, (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  
  const { role, is_active } = req.body;
  const user = db.getUser(Number(req.params.id));
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  // Don't let admins deactivate themselves
  if (user.id === req.user.id && is_active === false) {
    return res.status(400).json({ error: 'Cannot deactivate your own account' });
  }
  
  db.updateUser(user.id, { role, is_active });
  const updated = db.getUser(user.id);
  
  log(`👤 User updated by admin: ${user.username} (role: ${updated.role}, active: ${updated.is_active})`);
  
  res.json({ message: 'User updated', user: updated });
});

// ─── DELETE /api/auth/users/:id – Delete user (admin only) ────
router.delete('/users/:id', requireAuth, (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  
  const user = db.getUser(Number(req.params.id));
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  // Don't let admins delete themselves
  if (user.id === req.user.id) {
    return res.status(400).json({ error: 'Cannot delete your own account' });
  }
  
  db.deleteUser(user.id);
  log(`👤 User deleted by admin: ${user.username}`);
  
  res.json({ message: 'User deleted' });
});

export default router;
